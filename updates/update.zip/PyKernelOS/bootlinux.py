import os
os.system('cls' if os.name == 'nt' else 'clear')  # Clear the terminal
os.system('python "bios/bios.py"')  # Adjust the path here
